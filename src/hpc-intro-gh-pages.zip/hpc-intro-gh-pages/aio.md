---
permalink: /aio/index.html
---

{% comment %}
As a maintainer, you don't need to edit this file.
If you notice that something doesn't work, please
open an issue: <https://github.com/carpentries/styles/issues/new>
{% endcomment %}

{% include base_path.html %}

{% include aio-script.md %}
